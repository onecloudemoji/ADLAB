$x = get-itempropertyvalue -path hklm:\software\badblood -name '(default)'
if ($x -eq 1){& .\Invoke-BadBlood.ps1}
else {echo "its zero so no run"}